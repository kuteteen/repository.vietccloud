# -*- coding: utf-8 -*-

import xbmc, os

vipPath = 'special://masterprofile/addon_data/plugin.video.ccloud.tv/settings.xml'
vipName = os.path.join(xbmc.translatePath('special://home/addons'))
vip = os.path.join(xbmc.translatePath(vipPath))
