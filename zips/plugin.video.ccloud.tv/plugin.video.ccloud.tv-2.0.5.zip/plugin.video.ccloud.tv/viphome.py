# -*- coding: utf-8 -*-

import xbmc

vipPath = 'special://masterprofile/addon_data/plugin.video.ccloud.tv/settings.xml'
vipName = xbmc.translatePath('special://home/addons')
vip = xbmc.translatePath(vipPath)
